<?php
//Config Database
define('DB_HOST', 'localhost');
define('DB_USER', 'a329549_smm');
define('DB_PASS', '263941Dima');
define('DB_NAME', 'a329549_smm');
define('TIMEZONE', 'Africa/Abidjan');
define('ENCRYPTION_KEY', 'fb39b88e5b0c19c388fb576ad6f99f18');
