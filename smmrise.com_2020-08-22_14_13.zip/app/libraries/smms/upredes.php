<?php 
    echo "string";
?>
