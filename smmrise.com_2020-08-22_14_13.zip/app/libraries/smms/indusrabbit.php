<?php 
    echo "string";
?>
