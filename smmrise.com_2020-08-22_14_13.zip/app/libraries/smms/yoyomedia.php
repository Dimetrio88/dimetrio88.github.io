<?php 
  echo "string";
?>
