    <?=Modules::run(get_theme()."/header")?>
    
<section class="banner"  id="home">
      <div class="container">
        <div class="animatation-box-1">
          <img class="animated icon1" src="<?=BASE?>themes/pergo/assets/images/icon_red_circle.png">
          <img class="animated icon2" src="<?=BASE?>themes/pergo/assets/images/icon_yellow_tri.png">
          <img class="animated icon3" src="<?=BASE?>themes/pergo/assets/images/icon_yellow_circle.png">    
        </div>
       <div class="row">
          <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
            <div class="contents">
              <h2 class="head-title">
                <img src="https://smmrise.com/themes/pergo/assets/images/Text_na_g3.png" alt="text_na_g">
             
              <div class="head-button m-t-40">
                <a href="<?=cn('services')?>" class="btn btn-pill btn-outline-primary sign-up btn-lg"><?=lang("get_start_now")?></a>
              </div>
            </div>
          </div>  
        <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12 box-image">
            <div class="animation-2">
              <img class="intro-img" src="<?=BASE?>themes/pergo/assets/images/girl_and_desk.png" alt="girl-laptop">
              <img class="animated icon-1" src="<?=BASE?>themes/pergo/assets/images/icon_emoji_smile.png" alt="Emoji Smile">
              <img class="animated icon-2" src="<?=BASE?>themes/pergo/assets/images/icon_white_like.png" alt="Like icon">
              <img class="animated icon-3" src="<?=BASE?>themes/pergo/assets/images/icon_red_heart.png" alt="Red Heart Fill">
              <img class="animated icon-4" src="<?=BASE?>themes/pergo/assets/images/purple-like.png" alt="Like Icon">
              <img class="animated icon-5" src="<?=BASE?>themes/pergo/assets/images/icon_instagram.png" alt="Instagram icon">
              <img class="animated icon-6" src="<?=BASE?>themes/pergo/assets/images/icon_facebook_circle.png" alt="Facebook Icon">
              <img class="animated icon-7" src="<?=BASE?>themes/pergo/assets/images/icon_twitter.png" alt="Twitter">
              <img class="animated icon-10" src="<?=BASE?>themes/pergo/assets/images/icon_white_heart.png" alt="White Heart Unfill">
              <img class="animated icon-tree" src="<?=BASE?>themes/pergo/assets/images/tree.png" alt="tree">

            </div>
          </div>
        </div>
      </div>
    </section>
    
    <section class="core-services">
    </section>

 <section class="about-area">
      <div class="container">
        <div class="row">
          <div class="col-lg-5 col-md-12 col-sm-12 col-xs-12" data-aos="fade-left" data-aos-easing="ease-in" data-aos-delay="200">
            <div class="intro-img">
              <img class="img-fluid" src="<?=BASE?>themes/pergo/assets/images/best_service.png" alt="">
            </div>
          </div>

          <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12" data-aos="fade-right" data-aos-easing="ease-in" data-aos-delay="200">
            <div class="contents">
              <h2 class="head-title">
                <?=lang("best_smm_marketing_services")?>
              </h2>
              <p>
                              <iframe width="560" height="315" src="https://www.youtube.com/embed/uj0cWUBPg4g?controls=0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              </p>
              <div class="head-button">
                <a href="<?=cn('auth/signup')?>" class="btn btn-pill btn-signin btn-gradient btn-lg"><?=lang("get_start_now")?></a>
              </div>
            </div>
          </div>          
        </div>
      </div>
    </section>

    
    <div class="modal-infor">
      <div class="modal" id="notification">
        <div class="modal-dialog">
          <div class="modal-content">

            <div class="modal-header">
              <h4 class="modal-title"><i class="fe fe-bell"></i> <?=lang("Notification")?></h4>
              <button type="button" class="close" data-dismiss="modal"></button>
            </div>

            <div class="modal-body">
              <?=get_option('notification_popup_content')?>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><?=lang("Close")?></button>
            </div>
          </div>
        </div>
      </div>
    </div>


    <?=Modules::run(get_theme()."/footer")?>